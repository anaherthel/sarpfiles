In order to easily read in the data to the system we use, we rename the correspond instance

Cordeau and Laporte DARP instances:

R1a-R5a: 1-5
R1b-R5b: 6-10
R6a-R10a: 11-15
R6b-R10b: 16-20


For sarp large data:

SM1-SM9: 60-300